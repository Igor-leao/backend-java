package com.igor.cleanartch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanartchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanartchApplication.class, args);
	}

}
