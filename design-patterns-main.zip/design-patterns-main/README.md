# Curso Padrões de Projeto com Java

Códigos feitos para o curso/playlist Curso Padrões de Projeto com Java, no canal RinaldoDev do YouTube.

* Playlist no YouTube: https://www.youtube.com/playlist?list=PLuYctAHjg89bBeh25plGraaYiAsryusw6
* Canal no YouTube: https://www.youtube.com/rinaldodev

## Me siga para mais conteúdo educacional gratuito!

* Twitter: https://twitter.com/rinaldodev
* LinkedIn: https://www.linkedin.com/in/rinaldodev/
* Twitch: https://www.twitch.tv/rinaldodev
* Site: https://rinaldo.dev
